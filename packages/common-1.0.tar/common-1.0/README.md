
Emacs common function library

# how to install?

Use the elpa repository to automate installation

1. Edit your ~/.emacs configuration file and Add a repository source for emacs

```
(add-to-list 'package-archives
         '("elpa" . "https://elpa.typefo.com/packages/") t)
```

2. Use the `Alt + x` key, Execute the `package-install` command to install

```
M-x> package-install common
```

# How can I configure to use it?

1. The base configuration looks like this

    (require 'common)

2. Then just bind them to the key button you like

    (global-set-key (kbd "C-j") 'copy-current-line)
    (global-set-key (kbd "M-p") 'move-line-up)
    (global-set-key (kbd "M-n") 'move-line-down)

3. Start having fun ...
